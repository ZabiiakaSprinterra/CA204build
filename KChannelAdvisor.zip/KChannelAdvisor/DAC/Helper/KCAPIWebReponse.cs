﻿namespace KChannelAdvisor.DAC.Helper
{
    public class KCAPIWebReponse
    {
        public dynamic httpWebRes { get; set; }
        public dynamic response { get; set; }
        public string Message { get; set; }
        public bool IsSuccess { get; set; }
    }
}
