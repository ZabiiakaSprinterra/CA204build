﻿using PX.Data;

namespace KChannelAdvisor.DAC
{
    public class KCSecondAttributeMapping : KCAttributesMapping
    {
        public new abstract class aAttributeName : IBqlField { }
        public new abstract class isMapped : IBqlField { }
    }
}
