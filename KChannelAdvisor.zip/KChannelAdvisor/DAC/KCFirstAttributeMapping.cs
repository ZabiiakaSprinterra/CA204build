﻿using PX.Data;

namespace KChannelAdvisor.DAC
{
    public class KCFirstAttributeMapping : KCAttributesMapping
    {
        public new abstract class aAttributeName : IBqlField { }
        public new abstract class isMapped : IBqlField { }
        
    }
}
