﻿namespace KChannelAdvisor.Descriptor.MSMQ.Enums
{
    public enum SyncType
    {
        Unknown = -1,
        InventoryPrice,
        InventoryQuantity,
        VendorQuantity
    }
}
