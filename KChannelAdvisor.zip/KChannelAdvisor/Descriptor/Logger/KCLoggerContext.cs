﻿using System;

namespace KChannelAdvisor.Descriptor.Logger
{
    public class KCLoggerContext
    {
        public IFormatProvider FormatProvider { get; set; }
    }
}
