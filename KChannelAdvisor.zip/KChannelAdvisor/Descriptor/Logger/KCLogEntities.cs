﻿namespace KChannelAdvisor.Descriptor.Logger
{
    public class KCLogEntities
    {
        public const string Product = "Product";
        public const string ProductID = "Product ID";
        public const string Order = "Order";
        public const string Shipment = "Shipment";
        public const string PN = "Push Notifications";
    }
}
