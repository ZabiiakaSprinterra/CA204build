﻿
namespace KChannelAdvisor.Descriptor.API.Entity
{
    class KCAPIResponse
    {
        public string Response { get; set; }
    }
}
