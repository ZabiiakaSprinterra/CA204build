﻿namespace KChannelAdvisor.DAC.Helper
{
    public class KCInternalReponse
    {
        public string Message { get; set; }
        public bool IsSuccess { get; set; }
        public string Data { get; set; }
    }
}
