﻿namespace KChannelAdvisor.Descriptor.Helpers
{
    public class KCAttributeType
    {
        public const string ProductType = "Product Type";
        public const string System = "System";
        public const string Custom = "Custom";
        public const string Reserved = "Reserved";
    }
}
