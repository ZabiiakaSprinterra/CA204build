﻿namespace KChannelAdvisor.Descriptor.API.Entity
{
    public interface KCICAEntity
    {
    }
}
