﻿using System.ComponentModel;

namespace KChannelAdvisor.Descriptor.API.Mapper.MapCastHandlers
{
    internal class KCMapCastDTO
    {
        public PropertyDescriptor Property { get; set; }
        public object Field { get; set; }
    }
}
