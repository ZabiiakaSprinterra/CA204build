﻿namespace KChannelAdvisor.Descriptor.API.Constants
{
    public static class KCPaymentStatus
    {
        public const string Submitted = "Submitted";
        public const string Cleared = "Cleared";
        public const string Deposited = "Deposited";
    }
}
