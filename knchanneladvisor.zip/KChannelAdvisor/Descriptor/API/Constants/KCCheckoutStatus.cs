﻿namespace KChannelAdvisor.Descriptor.API.Constants
{
    public static class KCCheckoutStatus
    {
        public const string Completed = "Completed";
        public const string CCompleted = "C";
        public const string CompletedOffline = "CompletedOffline";
    }
}
